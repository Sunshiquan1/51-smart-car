#ifndef _DELAY_H
#define _DELAY_H
#include<reg52.h>

void Delay10ms()		//@11.0592MHz
{
	unsigned char i, j;

	i = 108;
	j = 145;
	do
	{
		while (--j);
	} while (--i);
}
void delayms(uint t)
{
	uint i,j;
	for(i=t;i>0;i--)
	{
		for(j=110;j>0;j--);
	}
}

#endif