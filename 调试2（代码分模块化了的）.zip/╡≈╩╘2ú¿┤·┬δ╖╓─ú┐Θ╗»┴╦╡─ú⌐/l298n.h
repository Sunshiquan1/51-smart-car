#ifndef _pwm_moto_H
#define _pwm_moto_H
#include<reg52.h>

#ifndef uchar
#define uchar unsigned char
#endif

#ifndef uint
#define uint  unsigned int
#endif


sbit ena=P2^2;
sbit in1=P2^3;
sbit in2=P2^4;
sbit enb=P2^7;
sbit in3=P2^5;
sbit in4=P2^6;

uchar leftt=0;			 //������ ��ʱ��0 ��һ��������pwm��
uchar pwmleft=0;		  //���pwmֵ
uchar pwmright=0;		  //�ұ�pwmֵ
#define right_back {in1=1,in2=0;}
#define right_go{in1=0,in2=1;}
#define left_back {in3=1,in4=0;}
#define left_go {in3=0,in4=1;}
#define stop {ena=0,in1=0,in2=0,enb=0,in3=0,in4=0;}


void initt0()
{
	TMOD=TMOD&0XF0;
	TMOD=TMOD|0X02;
	TH0=(256-100);		  //100us��ʱ������ã�
 	TL0=(255-100);
	TR0= 1;
	ET0= 1;
	EA=1;
}	  
void run0()
{
	pwmleft=15;pwmright=15;
	left_go;
	right_go;
}
void run()
{
	pwmleft=9;pwmright=7;
	left_go;
	right_go;
}
void run2()							 //����
{
	pwmleft=5;pwmright=5;
	left_go;
	right_go;
}

void backrun()
{
	pwmleft=12;pwmright=12;
	left_back;
	right_back;
}
void backrun1()
{
	pwmleft=20;pwmright=20;
	left_back;
	right_back;
}
void turnleft()							//ѡ����	  ѡ����
{
	pwmleft=13;pwmright=13;
	left_back;
	right_go;
}
void turnright()						//ѡ����	  ѡ����
{
	pwmleft=13;pwmright=13;
	left_go;
	right_back;
}
void runleft()							//Сת�䣨Ѱ����	  ѡ����
{
	pwmleft=8;pwmright=13;
	left_go;
	right_go;
}
void runright()						//Сת�䣨Ѱ����	  ѡ����
{
	pwmleft=13;pwmright=8;
	left_go;
	right_go;
}
void pwmout()
{
	if(leftt<=pwmright)
	{
		ena=1;
	}
	else ena=0;

	if(leftt<=pwmleft)
	{
		enb=1;
	}
	else enb=0;	
}



#endif