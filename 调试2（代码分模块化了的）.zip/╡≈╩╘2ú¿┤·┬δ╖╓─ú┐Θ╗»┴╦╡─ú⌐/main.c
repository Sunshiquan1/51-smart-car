#include<reg52.h>
#include"csb.h"
#include"l298n.h"
#include"hwai.h"
#include"delay.h"

#define uchar unsigned char	  //���������ͽ�����������
#define uint  unsigned int

sbit beep=P0^0;			//������
uchar c=20;
void init_t0() interrupt 1
{
	leftt++;
	if(leftt>=c)
	{
		leftt=0;	
	}
	pwmout();
}


void count1()									 //��s0����(��һ����)
{
	if(s1>28&&s1<=45)
	{
		run2();
	}									 
    else if(s1<=28)						  //���Ϸ�Χ��
	{
		if((hwai2==1&&hwai3==1)||(hwai2==1&&hwai3==0)) //����2�඼��||ֻ���Ҳ���				                                         //���Ҳ�������ź�
		{
			stop;delayms(100);backrun();delayms(250);
			turnleft();turnleft();delayms(80);run();					 
		}
		else if(hwai2==0&&hwai3==1)	    //ֻ�������
		{
			stop;delayms(100);backrun();delayms(250);
			turnright();delayms(80);
		}
		else if(hwai2==0&&hwai3==0)			                          //2�඼�� ǰ�����Ϊ��·��180����ת
		{
			stop;delayms(100);backrun();delayms(250);
			turnleft();delayms(300);		//delayms()���Ժã�ʹС��180����ת���ѵ���
		} 
	}
	else 
	run();
}

void int0() interrupt 0	
{
	if(flag2==0)
	{
		backrun1();delayms(100);backrun();delayms(170);//stop;delayms(100);backrun();delayms(250);
		turnleft();delayms(60);run();	
	}
	
}
void int1() interrupt 2	
{
	if(flag2==0)
	{
		backrun1();delayms(100);backrun();delayms(170);//stop;delayms(100);backrun();delayms(250);
		turnright();delayms(60);run();	
	}
	
}
void houmian()
{
	if(s0<=20)
	{
		beep=1;
		if((hwai2==1&&hwai3==1)||(hwai2==1&&hwai3==0))
		{
			runleft();delayms(30);run();	
		}
		else if(hwai2==0&&hwai3==1)
		{
			runright();delayms(30);run();
		}
		else if(hwai2==0&&hwai3==0)
		{
			run0();delayms(30);
		}
		else
		{
			run0();delayms(50);	
		}			
	}
	else beep=0;
}
void xunji()
{
	uchar i=0;
	c=30;	
	if(b1==0||b2==0||b3==0||b4==0||b5==0)
	{
		stop;delayms(300);
		while(1)
		{
		stop;delayms(10);		
		if(b1==0&&b2==0&&b3==0&&b4==0&&b5==0){Delay10ms();if(b1==0&&b2==0&&b3==0&&b4==0&&b5==0) {stop;}}
		else if(b1==0&b5==1) 
		{
			turnleft();delayms(10);
		}  
		else if(b2==0&&b1==1) {runleft();delayms(30);}
		else if(b3==0) {run();delayms(30);}
		else if(b4==0&&b5==1) {runright();delayms(30);}

		else if(b5==0&&b1==1)
		{
			turnright();delayms(10); 
			  
		}
		else
		{
			run();delayms(30);i++;
			if(i>=6)
			{	i=0;
				break;
			}	
		}
			
		}	
	}				
}



void main()
{	
	IP=0x2A;
	initt0();
	initt1();
	int0_init();
	int1_init();
	while(1)
	{
		rx0=rx1=0;c=20;
		s0=s1=100;
		run();
		startcsb1();									 //ǰ�泬����
		for(value=900;value>0;value--)
		{
			if(rx1==1)
			{
				flag2=1;
				opencount1();
				count1();
				break;
			}		
		}
		startcsb0();									 //������������
		for(value=1200;value>0;value--)
		{
			if(rx0==1)
			{				
				opencount0();
				houmian();				  //��������ź�				
				break;				
			}					
		}
		
		xunji();
	}	
}













